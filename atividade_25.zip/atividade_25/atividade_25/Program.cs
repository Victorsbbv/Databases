﻿using MySql.Data.MySqlClient;
using System;

namespace MySQLConsoleApp
{
    class Program
    {
        static string connectionString = "Server=localhost;Database=cadastro_db;Uid=root;Pwd=270503;";

        static void Main(string[] args)
        {
            int opcao;

            do
            {
                Console.WriteLine("\nEscolha uma opção:");
                Console.WriteLine("1 - Inserir Usuário");
                Console.WriteLine("2 - Ler Usuários");
                Console.WriteLine("3 - Atualizar Usuário");
                Console.WriteLine("4 - Deletar Usuário");
                Console.WriteLine("5 - Sair");

                opcao = int.Parse(Console.ReadLine());

                switch (opcao)
                {
                    case 1:
                        InserirUsuario();
                        break;
                    case 2:
                        LerUsuarios();
                        break;
                    case 3:
                        AtualizarUsuario();
                        break;
                    case 4:
                        DeletarUsuario();
                        break;
                    case 5:
                        Console.WriteLine("Saindo...");
                        break;
                    default:
                        Console.WriteLine("Opção inválida!");
                        break;
                }
            } while (opcao != 5);
        }

        static void InserirUsuario()
        {
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Email: ");
            string email = Console.ReadLine();

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO usuarios (nome, email) VALUES (@nome, @email)";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nome", nome);
                cmd.Parameters.AddWithValue("@email", email);

                cmd.ExecuteNonQuery();
                Console.WriteLine("Usuário inserido com sucesso!");
            }
        }

        static void LerUsuarios()
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM usuarios";
                MySqlCommand cmd = new MySqlCommand(query, conn);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"ID: {reader["id"]}, Nome: {reader["nome"]}, Email: {reader["email"]}");
                    }
                }
            }
        }

        static void AtualizarUsuario()
        {
            Console.Write("ID do usuário a ser atualizado: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Novo nome: ");
            string nome = Console.ReadLine();

            Console.Write("Novo email: ");
            string email = Console.ReadLine();

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE usuarios SET nome = @nome, email = @email WHERE id = @id";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@nome", nome);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.Parameters.AddWithValue("@email", email);

                cmd.ExecuteNonQuery();
                Console.WriteLine("Usuário atualizado com sucesso!");
            }
        }

        static void DeletarUsuario()
        {
            Console.Write("ID do usuário a ser deletado: ");
            int id = int.Parse(Console.ReadLine());

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                string query = "DELETE FROM usuarios WHERE id = @id";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
                Console.WriteLine("Usuário deletado com sucesso!");
            }
        }
    }
}
